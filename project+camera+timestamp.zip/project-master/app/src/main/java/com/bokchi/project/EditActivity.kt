package com.bokchi.project

import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.bokchi.project.databinding.ActivityEdit2Binding
import java.util.*

class EditActivity(intent: Intent) : AppCompatActivity() {
    // EditiActivity.kt와 activity_edit2.xml이 바인딩 되어 있습니다
    // 헷갈리거나 필요하다면 추후에 수정하겠습니다
    private lateinit var binding: ActivityEdit2Binding
    lateinit var style4Id: ImageButton
    lateinit var textViewYear: TextView
    lateinit var textViewMonth: TextView
    lateinit var textViewDate: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEdit2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        val yearmsg  = intent.getStringExtra("current-year")
        val monthmsg = intent.getStringExtra("current-month")
        val datemsg = intent.getStringExtra("current-date")

        binding.style4Id
        binding.textViewYear
        binding.textViewMonth
        binding.textViewDate

        textViewYear.text = yearmsg
        textViewMonth.text = monthmsg
        textViewDate.text = datemsg

        style4Id.setOnClickListener{
            if(style4Id.isPressed) {
                textViewYear.visibility = View.VISIBLE
                textViewMonth.visibility = View.VISIBLE
                textViewDate.visibility = View.VISIBLE
            }
            else{
                textViewYear.visibility = View.INVISIBLE
                textViewMonth.visibility = View.INVISIBLE
                textViewDate.visibility = View.INVISIBLE
            }
        }


    }
}