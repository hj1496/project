package com.bokchi.project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Editing : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editing)
    }
}